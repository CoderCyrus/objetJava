/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.centrale.projet.objet;

/**
 *
 * @author muruowang
 */
public class TestPoint2D {
     public static void main(String[] args){
        
         Point2D P1 = new Point2D(1,8);
        // P1(1,6);
         Point2D P2 = new Point2D();
        P1.affiche();
         P1.setX(11);
         P1.setY(9);
         P1.affiche();
         
         P1.setPosition(2, 9);
         P1.affiche();
         
         P1.translate(1, 1);
         P1.affiche();
         
         
        P2.affiche();
     }
}
